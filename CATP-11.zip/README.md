Os arquivos ex-1.cpp e resposta1.cpp contém os códigos com as alterações necessárias para os exercícios 1 e 4 (o arquivo resposta1.cpp teve que ser alterado para o exercício 1 pois o trecho de código fornecido no enunciado resultava em erro de compilação).

Os arquivos resposta2.cpp e resposta3.cpp contém as resoluções dos exercicios 2 e 3 respectivamente

